/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.MarketCapModel;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
/**
 *
 * @author ACER
 */
public class RippleController {
    private static final String rippleData = "*/../src/main/java/excel/Ripple.xlsx"; 
    private List<MarketCapModel> rippleMarketCap = new ArrayList<>();
     
     public void getAllData(){
         try{
             FileInputStream excel = new FileInputStream(new File(rippleData));
             Workbook workbook = new XSSFWorkbook(excel);
             Sheet sheet = workbook.getSheetAt(0);
             Iterator<Row> iterator = sheet.iterator();
             iterator.next();
             
             while(iterator.hasNext()){
                Row currentRow = iterator.next();
                Cell date   = currentRow.getCell(2);
                Cell open   = currentRow.getCell(3);
                Cell high   = currentRow.getCell(4);
                Cell low    = currentRow.getCell(5);
                Cell close  = currentRow.getCell(6);
                Cell volume = currentRow.getCell(7);
                Cell marketCap = currentRow.getCell(8);
                
                MarketCapModel mrkt = new MarketCapModel();
                
                mrkt.setDate(date.toString());
                mrkt.setOpen((double) open.getNumericCellValue());
                mrkt.setHigh((double) high.getNumericCellValue());
                mrkt.setLow((double) low.getNumericCellValue());
                mrkt.setClose((double) close.getNumericCellValue());
                mrkt.setVolume((int) volume.getNumericCellValue());
                mrkt.setClose((int) marketCap.getNumericCellValue());
                mrkt.setMarketCap((int) marketCap.getNumericCellValue());
                
                this.rippleMarketCap.add(mrkt);
             }
             
         } catch (FileNotFoundException ex) {
            Logger.getLogger(RippleController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(RippleController.class.getName()).log(Level.SEVERE, null, ex);
        }
     }
     
     public List<MarketCapModel> getList() {
        if(this.rippleMarketCap.isEmpty()){
            getAllData();
        }
        return this.rippleMarketCap;
    }
}
